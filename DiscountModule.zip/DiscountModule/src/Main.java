import models.OrderInput;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;

public class Main {
    public static void main(String[] args) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            OrderInput input = mapper.readValue(new File("input.json"), OrderInput.class);

            double finalPrice = DiscountService.calculateFinalPrice(
                    input.items,
                    input.discounts,
                    input.discounts.points
            );

            System.out.println("Final price: " + finalPrice + " THB");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
