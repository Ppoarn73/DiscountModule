package models;

public class DiscountConfig {
    public Coupon coupon;
    public OnTop onTop;
    public Seasonal seasonal;
    public int points;

    public static class Coupon {
        public String type; // fixed or percentage
        public double amount;
    }

    public static class OnTop {
        public String type; // category or points
        public String category;
        public double percentage;
    }

    public static class Seasonal {
        public int every;
        public double discount;
    }
}
