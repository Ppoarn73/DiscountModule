import models.Item;
import models.DiscountConfig;
import java.util.List;

public class DiscountService {
    public static double calculateFinalPrice(List<Item> items, DiscountConfig discount, int points) {
        
        //Check item price is not less than 0
        for (Item item : items) {
            if (item.price < 0) {
                throw new IllegalArgumentException("Item '" + item.name + "' price is less than 0 THB");
            }
        }

        double total = items.stream().mapToDouble(i -> i.price).sum();

        // Coupon discount
        if (discount.coupon != null) {
            if ("fixed".equalsIgnoreCase(discount.coupon.type)) {
                if (discount.coupon.amount < 0) {
                    throw new IllegalArgumentException("Fixed coupon discount is less than 0");
                }
                total =total- Math.min(discount.coupon.amount, total);
            } else if ("percentage".equalsIgnoreCase(discount.coupon.type)) {
                if (discount.coupon.amount < 0 || discount.coupon.amount > 100) {
                    throw new IllegalArgumentException("Coupon percentage must be between 0 and 100");
                }
                total = total- (total * discount.coupon.amount / 100);
            }
        }

        // OnTop discount
        if (discount.onTop != null) {
            if ("category".equalsIgnoreCase(discount.onTop.type)) {
                if (discount.onTop.percentage < 0 || discount.onTop.percentage > 100) {
                    throw new IllegalArgumentException("Category discount percentage must be between 0 and 100");
                }

                double categoryTotal = items.stream()
                        .filter(i -> i.category.equalsIgnoreCase(discount.onTop.category))
                        .mapToDouble(i -> i.price)
                        .sum();
                total =total- (categoryTotal * discount.onTop.percentage / 100);

            } else if ("points".equalsIgnoreCase(discount.onTop.type)) {
                if (points < 0) {
                    throw new IllegalArgumentException("Points are less than 0");
                }

                double maxPointDiscount = total * 0.20;
                total = total- Math.min(points, maxPointDiscount);
            }
        }

        // Seasonal discount
        if (discount.seasonal != null) {
            if (discount.seasonal.every <= 0 || discount.seasonal.discount < 0) {
                throw new IllegalArgumentException("Seasonal 'every' must be > 0 and discount >= 0.");
            }
            int multiplier = (int) (total / discount.seasonal.every);
            total =total- (multiplier * discount.seasonal.discount);
        }

        return Math.max(total, 0);     }
}

