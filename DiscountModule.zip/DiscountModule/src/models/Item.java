package models;

public class Item {
    public String name;
    public String category;
    public double price;
}
