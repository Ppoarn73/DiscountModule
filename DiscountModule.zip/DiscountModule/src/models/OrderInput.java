package models;

import java.util.List;

public class OrderInput {
    public List<Item> items;
    public DiscountConfig discounts;
}
